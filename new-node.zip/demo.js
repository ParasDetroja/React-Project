var http = require('http')
var fs = require('fs');
// running code start

const express = require('express')
const app = express()
var server = app.listen(4400, function () {
    var host = server.address().address
    var port = server.address().port
    console.log("Example app listening at http://%s:%s", host, port)
})
app.use(express.json());
app.post('/data', function (req, res) {
    var content = req.body.data;
    fs.writeFileSync('test.html', content);
    fs.readFile('test.html', function (err, data) {
        fs.writeFileSync('test-doc1.doc', data);
    });
    console.log('end');
    return;
})

// running code end
