import React, { useState } from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState, convertToRaw, ContentState } from 'draft-js';
import './App.css';
import CustomOption from './CustomOption';
import { stateToHTML } from 'draft-js-export-html';
function App() {
  const [data, setData] = useState(EditorState.createEmpty());
  const [htmlString, setHtmlString] = useState('');
  const onEditorStateChange = (editorState) => {
    setData(editorState);
    setHtmlString(stateToHTML(editorState.getCurrentContent()));
  };
  function getInputData() {
    let str = htmlString;
    console.log("str = ", str);
    const stringExtractor = extract(['{{', '}}']);
    const strings = stringExtractor(htmlString);
    console.log("variable = ", strings)
  }
  function extract([beg, end]) {
    const matcher = new RegExp(`${beg}(.*?)${end}`, 'gm');
    const normalise = (str) => str.slice(beg.length, end.length * -1);
    return function (str) {
      return str.match(matcher).map(normalise);
    }
  }
  function checkUpdate(editorState) {
    // editorState.createEmpty();

  }

  return (
    <div>
      <h2>Using React-Draft-wysiwyg-demo</h2>
      <Editor
        editorState={data}
        toolbarClassName="toolbarClassName"
        wrapperClassName="wrapperClassName"
        editorClassName="editorClassName"
        onEditorStateChange={onEditorStateChange}
        toolbarCustomButtons={[<CustomOption />]}
      />
      <div>
        <button type="button" onClick={getInputData} className="btn-save">Save</button>
        {/* <button type="button" onClick={checkUpdate}>Clear & check</button> */}
      </div>
    </div>
  );
}
// onClick={() => { console.log('milan : ', convertToRaw(data.getCurrentContent())); }}
export default App;
